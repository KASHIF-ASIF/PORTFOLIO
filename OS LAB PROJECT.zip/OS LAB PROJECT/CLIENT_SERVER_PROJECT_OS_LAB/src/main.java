/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KASHIF
 */
public class main {
    
    public static void main(String args[]) throws InterruptedException{
    
        WELCOME wel = new WELCOME();
        wel.setVisible(true);
         wel.progress.setVisible(true);
    for(int i = 0; i <=100; i++)
            {
                        Thread.sleep(100);
                wel.progress.setValue(i);
                wel.number.setText(Integer.toString(i)+" %");
                if(i==10)
                wel.text.setText("Loading...");
                else if(i==30)
                wel.text.setText("Turning On Module...");
                else if(i==50)
                wel.text.setText("Connecting Database...");
                else if(i==70)
                wel.text.setText("Connecting Server & Client...");
                else if(i==90)
                wel.text.setText("Connection Successfully...");
                else if(i==100)
                {
                   choice c=new choice();
                   c.setVisible(true);
                    wel.dispose();
                }
                    
            }}
    
}