
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KASHHIF
 */
public class InsertRecord {
    int id=0;
     ConnectOracle con_obj = new ConnectOracle();
    Connection con=con_obj.EstablishCon();
    Statement stmt = null;
    PreparedStatement pstmt = null;
    ResultSet res;
    DefaultTableModel d;
    
     public void Insert(String a,String b,String c)
    {
         try {
             String query="select count(id) FROM message";
             pstmt = con.prepareStatement(query);
             res = pstmt.executeQuery();
             while (res.next()) {
                 id=Integer.parseInt(res.getString(1));
             }
         }catch (SQLException ex) {
                 JOptionPane.showMessageDialog(null, "CAN'NT ABLE TO ASSIGN ID");
         }
             
             try {
                 String query="insert into message values("+(id+1)+",'"+a+"','"+b+"',sysdate,'"+c+"')";
                 pstmt = con.prepareStatement(query);
                 res = pstmt.executeQuery();
             } catch (SQLException ex) {
                 
                 JOptionPane.showMessageDialog(null, "BUY THIS SOFTWARE TO STORE MORE MESSAGE'S!!!");
             }
              try {
                 String query="commit";
                 pstmt = con.prepareStatement(query);
                 res = pstmt.executeQuery();
             } catch (SQLException ex) {
             }
          
    }
    
}
